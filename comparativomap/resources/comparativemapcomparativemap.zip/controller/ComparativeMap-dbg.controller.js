sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "comparativemap/comparativemap/model/models",
    "comparativemap/comparativemap/controller/services/ODataService",
    "comparativemap/comparativemap/controller/services/SimulationMapper",
    "comparativemap/comparativemap/controller/services/Dialogs",
    "comparativemap/comparativemap/controller/services/AwardService",
    "comparativemap/comparativemap/controller/helpers/Debug",
    "comparativemap/comparativemap/controller/helpers/Formatters",
    "comparativemap/comparativemap/controller/helpers/ErrorHandler",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/Device",
    "comparativemap/comparativemap/controller/helpers/buildRequestsBySupplier",
    "sap/ui/export/Spreadsheet",
    "sap/ui/export/library",
    "sap/ui/core/UIComponent",
    "comparativemap/comparativemap/controller/prefs/DraftStore",
    "sap/ui/core/format/NumberFormat"
  ],
  function (
    Controller,
    Models,
    ODataSvc,
    Mapper,
    Dialogs,
    AwardSvc,
    Debug,
    Fmt,
    ErrorHandler,
    MessageToast,
    MessageBox,
    Device,
    Build,
    Spreadsheet,
    exportLibrary,
    UIComponent,
    Drafts,
    NumberFormat
  ) {
    "use strict";
    const EdmType = exportLibrary.EdmType;

    return Controller.extend(
      "comparativemap.comparativemap.controller.ComparativeMap",
      {
        formatter: Fmt,

        // ===========================================================
        // 1. INICIALIZAÇÃO
        // ===========================================================
        onInit() {
          const view = this.getView();

          // Modelos base
          view.setModel(Models.createVM(), "vm");
          view.setModel(Models.createQM(), "qm");

          // Modelo de resultados
          let res = view.getModel("res");
          if (!res) {
            res = new sap.ui.model.json.JSONModel({ header: {}, rows: [], totals: {} });
            view.setModel(res, "res");
          }

          // Layout compacto
          view.addStyleClass("sapUiSizeCompact");

          // Registra estado padrão da tabela (ordem de colunas)
          Drafts.registerDefaultState(this);

          // 🔵 Liga handler na rota pra rodar SEMPRE que a tela for ativada
          const oRouter = UIComponent.getRouterFor(this);
          this._fnRouteMatched = this._onRouteMatched.bind(this);
          oRouter.getRoute("RouteComparativeMap").attachPatternMatched(this._fnRouteMatched);

          // Autosave ao sair/recarregar a página
          this._onUnloadSave = () => {
            try { Drafts.save(this); } catch (e) { }
          };
          window.addEventListener("beforeunload", this._onUnloadSave);
        },

        // Disparado toda vez que a rota "RouteComparativeMap" é ativada
        _onRouteMatched() {
          console.log("[ComparativeMap] route matched → offerRestoreOnEnter");
          Drafts.offerRestoreOnEnter(this);
        },

        onExit() {
          // Fecha dialog de resultado se ainda existir
          if (this._dlgRes) {
            this._dlgRes.destroy(true);
            this._dlgRes = null;
          }

          // Remove o listener do beforeunload
          if (this._onUnloadSave) {
            window.removeEventListener("beforeunload", this._onUnloadSave);
            this._onUnloadSave = null;
          }

          // Desliga o handler da rota pra não vazar memória
          const oRouter = UIComponent.getRouterFor(this);
          if (this._fnRouteMatched) {
            oRouter.getRoute("RouteComparativeMap").detachPatternMatched(this._fnRouteMatched);
            this._fnRouteMatched = null;
          }
        },

        // ===========================================================
        // 2. BUSCA PRINCIPAL
        // ===========================================================
        async onBuscar() {
          const view = this.getView();
          const odata = view.getModel();
          const vm = view.getModel("vm");
          const qm = view.getModel("qm");
          const mdcTbl = view.byId("tblDocs");

          const newDocId = (view.byId("inputDoID").getValue() || "").trim();
          const oldDocId = vm.getProperty("/header/docId");

          try {
            if (!odata) throw new Error("Modelo OData V4 não encontrado.");
            if (!newDocId) {
              MessageToast.show("Informe o Doc ID");
              return;
            }

            sap.ui.core.BusyIndicator.show(0);
            mdcTbl?.setBusy(true);

            if (oldDocId && oldDocId !== newDocId) {
              console.log(`💾 Salvando draft anterior (${oldDocId}) antes de trocar...`);
              Drafts.save(this, true);
            }

            view.byId("vsdFilterBar")?.setVisible(false);
            view.byId("vsdFilterLabel")?.setText("");

            // 2. Reset layout se não houver draft salvo
            const hasSavedDraft = Drafts.hasDraft(newDocId);
            if (!hasSavedDraft) {
              console.log("🧹 Novo DocID detectado. Resetando layout...");
              Drafts.resetToDefault(this);
            }

            // Prepara containers
            qm?.setProperty("/idByKey", {});
            qm?.setProperty("/simSourceRows", []);

            // 3. Busca dados
            const res = await ODataSvc.fetchQuotes(view, newDocId);

            const rows = (Array.isArray(res?.items) ? res.items : []).map(r => ({
              ...r,
              itemId: r.itemId ?? r.ItemId ?? null,
              itemDescription: r.itemDescription,
              price: (r.price !== undefined && r.price !== null) ? Number(r.price) : r.price,
              _originalQty: Number(r.quantity) || 0
            }));

            const header = res?.header || {};
            const headerRows = res?.header ? [res.header] : [];

            // 4. Aplica dados + draft
            if (hasSavedDraft) {
              console.log(`♻️ Draft encontrado para ${newDocId}. Restaurando...`);
              Drafts.restoreWithNewData(this, newDocId, header, headerRows, rows);
            } else {
              vm.setProperty("/header", header);
              vm.setProperty("/headerRows", headerRows);
              vm.setProperty("/rows", rows);

              if (mdcTbl && mdcTbl.isA("sap.ui.mdc.Table")) {
                mdcTbl.rebind();
              }

              setTimeout(() => {
                console.log(`💾 Salvando estado inicial para ${newDocId}...`);
                Drafts.save(this, true);
              }, 500);
            }

            if (!rows.length) {
              MessageToast.show("Nenhum item retornado para esse Doc ID.");
            }

          } catch (e) {
            ErrorHandler.handle(e, "Erro ao buscar DocID");
          } finally {
            // 🔵 SEMPRE TIRA O BUSY
            mdcTbl?.setBusy(false);
            sap.ui.core.BusyIndicator.hide();
          }
        },

        onQtyInlineChange(ev) {
          const ctx = ev.getSource()?.getBindingContext("vm");
          if (!ctx) return;
          const row = ctx.getObject() || {};
          const max = Number(row._originalQty) || 0;
          let v = Number(row.quantity);
          if (isNaN(v) || v < 0) v = 0;
          if (max && v > max) v = max;
          row.quantity = Math.floor(v);
          ctx.getModel().checkUpdate(true);
          Drafts.autoSave(this);
        },

        onCloseDialog(ev) {
          Dialogs.closeAny(this, ev);
        },

        // ===========================================================
        // 3. SIMULAÇÃO (ATUALIZADO PARA MDC)
        // ===========================================================
        async onSimularPress() {
          const view = this.getView();
          const vm = view.getModel("vm");
          const qm = view.getModel("qm");

          console.log("🚀 [SIMULAR] Iniciando processo de simulação...");

          // Limpa modelo de resultados
          const resModel = this.getView().getModel("res");
          if (resModel?.setSizeLimit) resModel.setSizeLimit(5000);
          resModel.setProperty("/header", {});
          resModel.setProperty("/rows", []);
          resModel.setProperty("/totals", {});

          try {
            const mdcTbl = this.byId("tblDocs");
            if (!mdcTbl) throw new Error("Tabela 'tblDocs' não encontrada na View.");

            // --- Coleta Seleção (Estratégia Segura) ---
            let rows = [];
            let selectionSource = "Nenhuma";

            // 1. Tenta API Nativa do MDC (Prioridade Máxima)
            if (typeof mdcTbl.getSelectedContexts === "function") {
              // Se essa função existe, ELA é a dona da verdade.
              const contexts = mdcTbl.getSelectedContexts();
              if (contexts) {
                rows = contexts.map((c) => c.getObject()).filter(Boolean);
                selectionSource = "MDC Direct API";
              }
            }

            // 2. Fallback: Acessa a tabela interna (Inner Table)
            // 🛑 CORREÇÃO: Só entra aqui se a fonte ainda for "Nenhuma".
            // Se a API do MDC retornou 0 linhas, aceitamos que são 0 linhas e não tentamos "forçar" na interna.
            if (selectionSource === "Nenhuma" && mdcTbl.isA && mdcTbl.isA("sap.ui.mdc.Table")) {
              console.warn("⚠️ [SIMULAR] API do MDC não detectada. Tentando Inner Table...");

              const inner = (typeof mdcTbl.getInnerTable === "function" ? mdcTbl.getInnerTable() : null)
                || mdcTbl._oTable;

              if (inner) {
                if (inner.isA("sap.m.Table")) {
                  selectionSource = "Inner sap.m.Table";
                  rows = inner.getSelectedItems()
                    .map((it) => it.getBindingContext("vm")?.getObject?.())
                    .filter(Boolean);
                }
                else if (inner.isA("sap.ui.table.Table")) {
                  // GridTable: Precisamos cuidar com o Plugin de Seleção
                  selectionSource = "Inner sap.ui.table.Table (Grid)";

                  // Verifica se há plugins bloqueando o getSelectedIndices
                  const hasSelectionPlugin = inner.getPlugins && inner.getPlugins().some(p => p.isA("sap.ui.table.plugins.SelectionPlugin"));

                  if (hasSelectionPlugin) {
                    console.warn("🚫 [SIMULAR] Plugin de seleção detectado na GridTable. getSelectedIndices ignorado para evitar crash.");
                    // Se tem plugin e o MDC (passo 1) não resolveu, provavelmente não há seleção acessível via legacy.
                    rows = [];
                  } else {
                    const idxs = inner.getSelectedIndices() || [];
                    rows = idxs.map((i) => {
                      const ctx = inner.getContextByIndex(i);
                      return ctx ? ctx.getObject() : null;
                    }).filter(Boolean);
                  }
                }
              }
            } else if (selectionSource === "Nenhuma" && mdcTbl.isA("sap.m.Table")) {
              // Caso legado puro (sem MDC)
              selectionSource = "Legacy sap.m.Table";
              rows = mdcTbl.getSelectedItems().map(it => it.getBindingContext("vm")?.getObject()).filter(Boolean);
            }

            console.log(`📊 [SIMULAR] Fonte da seleção: ${selectionSource}`);
            console.log(`📦 [SIMULAR] Linhas brutas selecionadas: ${rows.length}`, rows);

            // AGORA SIM: Se rows estiver vazio, lançamos o erro amigável (sem crashar antes)
            if (!rows.length) {
              // Se for MDC, tenta limpar visualmente só pra garantir
              if (mdcTbl.isA("sap.ui.mdc.Table")) {
                const inner = mdcTbl.getInnerTable && mdcTbl.getInnerTable();
                // Verifica se o método existe e se não vai dar conflito com plugin antes de chamar
                if (inner && inner.clearSelection && !inner.getPlugins?.().some(p => p.isA("sap.ui.table.plugins.SelectionPlugin"))) {
                  try { inner.clearSelection(); } catch (e) { }
                }
              }

              MessageBox.warning("Selecione pelo menos 1 item para poder simular o pedido.");
              return; // Para a execução aqui de forma limpa
            }

            // --- Validação de Integridade ---
            // Filtra linhas que não tenham ID de material ou ItemId (lixo de memória ou linha vazia)
            const validRows = rows.filter((r) => r && (r.MaterialCode || r.materialCode || r.ItemId || r.itemId));

            if (rows.length !== validRows.length) {
              console.warn(`⚠️ [SIMULAR] Algumas linhas foram descartadas por falta de ID. Originais: ${rows.length}, Válidas: ${validRows.length}`);
            }
            rows = validRows;

            if (!rows.length) {
              // Tenta limpar a seleção visualmente se for inconsistente
              if (mdcTbl.isA("sap.ui.mdc.Table")) {
                const inner = mdcTbl.getInnerTable && mdcTbl.getInnerTable();
                if (inner && inner.clearSelection) inner.clearSelection();
              }
              throw new Error("Seleção inválida: Itens sem Material ou ID. A seleção foi limpa, tente novamente.");
            }

            const zeroPriceRows = rows.filter(r => {
              const p = Number(r.price); // Garante que é number (vinha do onBuscar)
              return !p || p <= 0.000001; // Verifica se é 0, negativo ou NaN
            });

            if (zeroPriceRows.length > 0) {
              // Monta lista amigável para o usuário saber qual item corrigir
              const listaItens = zeroPriceRows
                .map(r => `• ${r.itemDescription || r.materialCode || "Item sem nome"}`)
                .join("\n");

              MessageBox.error(
                "Atenção: A simulação não pode ser realizada com preços zerados (0,00).",
                {
                  details: "Os seguintes itens estão com preço R$ 0,00:\n\n" + listaItens,
                  contentWidth: "400px"
                }
              );

              // Tira o busy e para a execução aqui
              mdcTbl?.setBusy(false);
              return;
            }

            // --- Preparação BAPI ---
            console.log("⚙️ [SIMULAR] Preparando payload para Mapper...");
            qm.setProperty("/simSourceRows", rows); // Guarda referência para cruzar na volta

            Mapper.prepareQMFromSelection(rows, qm);
            const requests = Build.buildRequestsFromSelection(rows, vm);

            console.log("📤 [SIMULAR] Requests gerados (Payload):", requests);

            // --- Validação Header/Items ---
            const headerMissing = [];
            const itemMissing = [];

            requests.forEach((req, ridx) => {
              const h = req.header || {};

              // Normaliza código do fornecedor da BAPI
              const vendorCode = (h.vendor && String(h.vendor).replace(/\D/g, "").replace(/^0+/, "")) || "";

              let nomeForn = `Requisição #${ridx + 1}`;

              if (vendorCode) {
                // Procura a linha original que tenha o mesmo fornecedor
                const rowEncontrada = rows.find((r) => {
                  const cand = [
                    r.lifnr,
                    r.LIFNR,
                    r.supplierId,
                    r.SupplierId,
                    r.supplierID,
                    r.suppliercode,
                    r.supplierCode,
                    r.SupplierCode,
                    r.vendor,
                    r.Vendor,
                    r.vendorId,
                    r.VendorId
                  ].find(Boolean); // pega o primeiro que existir

                  if (!cand) return false;

                  const rowCode = String(cand).replace(/\D/g, "").replace(/^0+/, "");
                  return rowCode === vendorCode;
                });

                if (rowEncontrada) {
                  // pega o nome do fornecedor da linha original
                  nomeForn =
                    rowEncontrada.supplierName ||
                    rowEncontrada.SupplierName ||
                    rowEncontrada.vendorName ||
                    rowEncontrada.VendorName ||
                    `Fornecedor ${vendorCode}`;
                } else {
                  nomeForn = `Fornecedor ${vendorCode}`;
                }
              }

              // A partir daqui, todas as mensagens vão usar o NOME do fornecedor
              const tag = `Fornecedor: ${nomeForn}`;

              if (!h.docType) headerMissing.push(`${tag}: Tipo Pedido (docType)`);
              if (!h.compCode) headerMissing.push(`${tag}: Empresa (compCode)`);
              if (!h.purchOrg) headerMissing.push(`${tag}: Org. Compras`);
              if (!h.vendor) headerMissing.push(`${tag}: Fornecedor`);

              (req.items || []).forEach((it, i) => {
                const itemRef = `Item ${(i + 1)}`;
                const itTag = `Fornecedor: ${nomeForn} > ${itemRef}`;

                if (!it.plant) {
                  itemMissing.push(`${itTag}: Centro (plant) não informado.`);
                }
                if (!it.quantity || it.quantity <= 0) {
                  itemMissing.push(`${itTag}: Quantidade inválida.`);
                }
              });
            });

            if (headerMissing.length || itemMissing.length) {
              const msg = [
                headerMissing.length ? "⚠️ Cabeçalho:\n- " + headerMissing.join("\n- ") : "",
                itemMissing.length ? "⚠️ Itens:\n- " + itemMissing.join("\n- ") : ""
              ].filter(Boolean).join("\n\n");
              throw new Error(msg);
            }

            // --- Normalização para mapeamento de volta ---
            const normVendor = (v) => (v == null ? "" : String(v).replace(/\D/g, "").padStart(10, "0"));
            // Cria um Map para saber quais linhas originais geraram qual request de fornecedor
            const vendorToSrc = new Map(
              (requests || []).map((req) => [
                normVendor(req?.header?.vendor),
                Array.isArray(req.sourceRows) ? req.sourceRows : []
              ])
            );

            // Limpa sourceRows do payload final para não pesar o JSON enviado ao backend
            const payloadRequests = (requests || []).map(({ header, items, schedules, testRun }) => ({
              header,
              items,
              schedules,
              testRun
            }));

            sap.ui.core.BusyIndicator.show(0);

            // --- Chamada BAPI ---
            console.log("📡 [SIMULAR] Enviando para ODataSvc.simularPO...");
            const results = await ODataSvc.simularPO(view, payloadRequests, 4);
            console.log("📥 [SIMULAR] Retorno OData:", results);

            // Verifica erros estruturais do retorno
            const structuralErrors = (Array.isArray(results) ? results : []).filter((r) => r?.error || r?.success === false);
            if (structuralErrors.length) {
              const firstErr = structuralErrors[0];
              console.error("❌ [SIMULAR] Erro estrutural no retorno:", firstErr);
              ErrorHandler.handle(
                new Error(firstErr?.message || "Falha técnica na simulação."),
                "Erro na simulação",
                { showDetailsPanel: true, details: firstErr }
              );
              return;
            }

            // Verifica mensagens de erro de negócio (Tipo E ou A)
            const allMsgs = (Array.isArray(results) ? results : []).flatMap((r) => r?.returnMessages || r?.mensagens || []);
            const hasErrorMsg = allMsgs.some((m) => m.type === "E" || m.type === "A");

            if (hasErrorMsg) {
              console.warn("⚠️ [SIMULAR] Erros de negócio retornados pela BAPI:", allMsgs);
              Dialogs.showBapiMessages(allMsgs);
              return;
            }

            // --- Processamento do Retorno ---
            const resultsArr = Array.isArray(results) ? results : [];
            let resRows = [];

            try {
              resRows = resultsArr.flatMap((r) => {
                const v = normVendor(r?.header?.fornecedor || r?.header?.vendor || "");
                // Tenta pegar as linhas originais específicas desse fornecedor
                const srcRows = vendorToSrc.get(v) || (qm.getProperty("/simSourceRows") || []);
                return Mapper.buildResRowsFromBapiResult(r, qm, srcRows);
              });
            } catch (err) {
              console.error("❌ [SIMULAR] Erro no Mapper (buildResRows):", err);
              // Fallback genérico
              const globalSrc = qm.getProperty("/simSourceRows") || [];
              resRows = resultsArr.flatMap((r) => Mapper.buildResRowsFromBapiResult(r, qm, globalSrc));
            }

            console.log("✅ [SIMULAR] Linhas processadas para exibição:", resRows);

            // 🛑 FALTOU ISSO AQUI: Atualizar o Model para a tabela MDC ler
            if (resModel) {
              resModel.setProperty("/rows", resRows);
              resModel.setProperty("/header", resultsArr[0]?.header || {});
            }

            Dialogs.openResultDialog(view, resRows, this);
            if (allMsgs.length) Dialogs.showBapiMessages(allMsgs);

          } catch (err) {
            console.error("🔥 [SIMULAR] Exception:", err);
            ErrorHandler.handle(err, "Erro ao simular pedido", {
              showDetailsPanel: true,
              contentWidth: "640px"
            });
          } finally {
            sap.ui.core.BusyIndicator.hide();
          }
        },

        // ===========================================================
        // 4. PREMIAÇÃO
        // ===========================================================
        onAwardQtyChangeRes(ev) {
          const input = ev.getSource();
          const ctx = input.getBindingContext("res");
          if (!ctx) return;

          const row = ctx.getObject() || {};

          // Normaliza valor digitado
          let v = Math.floor(Number(input.getValue()));
          if (!Number.isFinite(v) || v < 0) {
            v = 0;
          }

          row.qtyAward = v;
          ctx.getModel().checkUpdate(true);
          input.setValue(String(row.qtyAward));

          const original = Math.floor(Number(row.originalQty) || 0);

          // Reseta estados por padrão
          input.setValueState(sap.ui.core.ValueState.None);
          input.setValueStateText("");

          if (original > 0) {
            if (v > original) {
              // 🔺 Acima da original
              input.setValueState(sap.ui.core.ValueState.Warning);
              input.setValueStateText(`Aviso: quantidade acima da original (${original}).`);
              sap.m.MessageToast.show(
                `Qtd premiada (${v}) maior que a original (${original}).`
              );
            } else if (v < original) {
              // 🔻 Abaixo da original
              input.setValueState(sap.ui.core.ValueState.Warning);
              input.setValueStateText(`Aviso: quantidade abaixo da original (${original}).`);
              sap.m.MessageToast.show(
                `Qtd premiada (${v}) menor que a original (${original}).`
              );
            }
          }
        },


        async onAwardDirect() {
          const view = this.getView();
          const vm = view.getModel("vm");
          const resModel = view.getModel("res");

          // 1. PEGAR A TABELA CORRETAMENTE (Pelo ID do Fragmento)
          let tbl = this.byId("tblRes");

          if (!tbl) {
            tbl = sap.ui.getCore().byId("fragmentId--tblRes");
            if (!tbl && this._dlgRes) {
              tbl = this._dlgRes.getContent().find(c => c.isA && c.isA("sap.ui.mdc.Table"));
            }
          }

          if (!tbl) {
            MessageBox.error("Erro interno: Tabela de resultados (tblRes) não encontrada.");
            return;
          }

          // 2. SELEÇÃO
          const selected = this._collectRowsFromTable(tbl, "res", resModel, "/rows");

          if (!selected.length) {
            MessageToast.show("Selecione ao menos uma linha para premiar.");
            return;
          }

          const allRows = selected;

          const supplierBids = AwardSvc.validarEMontarPayload(
            allRows,
            selected,
            this._ensureInvitationResourceId.bind(this)
          );

          if (!supplierBids) return;

          const sEventId =
            vm.getProperty("/header/docId") ||
            resModel.getProperty("/header/docId");
          if (!sEventId) {
            MessageBox.error("DocID do evento não encontrado no header.");
            return;
          }

          const baseTitle = "Premiação via UI (MDC)";
          const now = new Date();
          const iso = now.toISOString();                     // 2025-11-27T18:23:45.123Z
          const stamp = iso.slice(0, 19).replace("T", " ");  // 2025-11-27 18:23:45
          const rand = Math.floor(Math.random() * 1000);     // 0–999
          const finalTitle = `${baseTitle} - ${stamp} #${rand}`;

          sap.ui.core.BusyIndicator.show(0);
          try {
            const out = await ODataSvc.createScenario(view, {
              eventId: sEventId,
              title: finalTitle,      // 👈 agora SEMPRE diferente
              scenarioType: 0,
              supplierBids,
            });

            if (out?.success) {
              MessageBox.success(
                `Cenário criado com sucesso!\n` +
                `Título: ${finalTitle}\n` +
                `Scenario ID: ${out.scenarioId || "(n/a)"}`
              );
              this._dlgRes?.close();
            } else {
              MessageBox.warning(
                "O cenário foi processado, mas o backend não retornou 'success=true'. Verifique no Ariba."
              );
            }
          } catch (e) {
            ErrorHandler.handle(e, "Erro ao criar cenário de premiação", {
              showDetailsPanel: true,
              contentWidth: "640px",
            });
          } finally {
            sap.ui.core.BusyIndicator.hide();
          }
        },

        // ===========================================================
        // 5. HELPERS & EXPORT
        // ===========================================================
        _ensureInvitationResourceId(invId, email) {
          if (!invId) return null;
          const s = String(invId);
          if (s.includes("_")) return s;
          if (email) return `${s}_${String(email)}`;
          return s;
        },

        _collectRowsFromTable(table, modelName, modelFallback, pathFallback) {
          if (!table) return [];

          let selected = [];
          if (typeof table.getSelectedContexts === "function") {
            selected = (table.getSelectedContexts(modelName) || []).map(c => c.getObject());
          } else if (table.isA && table.isA("sap.ui.mdc.Table")) {
            const inner = table.getInnerTable && table.getInnerTable();
            if (inner) {
              if (typeof inner.getSelectedContexts === "function") {
                selected = (inner.getSelectedContexts(modelName) || []).map(c => c.getObject());
              } else if (inner.isA && inner.isA("sap.ui.table.Table")) {
                const idxs = inner.getSelectedIndices() || [];
                selected = idxs.map(i => inner.getContextByIndex(i)).filter(Boolean).map(ctx => ctx.getObject());
              }
            }
          }
          if (selected.length) return selected;

          let binding = null;
          if (typeof table.getRowBinding === "function") binding = table.getRowBinding();
          else if (typeof table.getBinding === "function") binding = table.getBinding("items");

          if (binding && typeof binding.getLength === "function") {
            const len = binding.getLength();
            if (len > 0 && typeof binding.getContexts === "function") {
              const ctxs = binding.getContexts(0, len);
              return ctxs.map(c => c.getObject());
            }
          }

          return modelFallback?.getProperty(pathFallback) || [];
        },

        onExportExcel() {
          const view = this.getView();
          const vm = view.getModel("vm");
          const tbl = view.byId("tblDocs");

          const rows = this._collectRowsFromTable(tbl, "vm", vm, "/rows");
          if (!rows.length) {
            sap.m.MessageToast.show("Nada para exportar.");
            return;
          }
          this._doExport(rows, vm?.getProperty("/header/docId") || "MapaComparativo");
        },

        onExportExcelRes() {
          const view = this.getView();
          const tbl = this._dlgRes?.getContent?.()[0];
          const resModel = view.getModel("res");

          if (!tbl || !resModel) {
            sap.m.MessageToast.show("Janela de resultados não está aberta.");
            return;
          }
          const rows = this._collectRowsFromTable(tbl, "res", resModel, "/rows");
          if (!rows.length) {
            sap.m.MessageToast.show("Nada para exportar.");
            return;
          }
          this._doExport(rows, view.getModel("vm")?.getProperty("/header/docId") || "Simulacao", true);
        },

        formatNumberOrDash: function (sValue) {
          // Se for nulo, undefined ou string vazia, retorna o traço
          if (sValue === null || sValue === undefined || sValue === "") {
            return "-";
          }

          // Tenta converter para float
          var fValue = parseFloat(sValue);

          // Se não for número válido (NaN), retorna traço
          if (isNaN(fValue)) {
            return "-";
          }

          // Instancia o formatador (Padrão brasileiro: ponto no milhar, vírgula no decimal)
          var oFloatFormat = NumberFormat.getFloatInstance({
            minFractionDigits: 2,
            maxFractionDigits: 2,
            groupingEnabled: true,
            groupingSeparator: ".",
            decimalSeparator: ","
          });

          return oFloatFormat.format(fValue);
        },

        formatIntegerOrDash: function (sValue) {
          if (sValue === null || sValue === undefined || sValue === "") {
            return "-";
          }

          var fValue = parseFloat(sValue);

          if (isNaN(fValue)) {
            return "-";
          }

          var oIntegerFormat = NumberFormat.getFloatInstance({
            minFractionDigits: 0,
            maxFractionDigits: 0,
            groupingEnabled: true,
            groupingSeparator: "."
          });

          return oIntegerFormat.format(fValue);
        },

        formatCleanMaterial: function (sValue) {
          if (!sValue) {
            return "-";
          }

          const match = sValue.match(/^(\d+)\s+(.+)/);

          if (match) {
            const sCodigo = match[1];
            const sDescricao = match[2];
            return `${sDescricao} (${sCodigo})`;
          }

          return sValue;
        },

        _doExport(rows, docId, isResult = false) {
          const toNum = (v) => {
            if (v == null || v === "") return null;
            const n = Number(String(v).replace(/\./g, "").replace(",", "."));
            return Number.isFinite(n) ? n : null;
          };

          const NUMERIC = isResult
            ? ["originalQty", "quantity", "qtyAward", "price", "icms", "ipi", "total", "poItem"]
            : ["quantity", "price", "mva", "Extrinsic_Aliquota_ICMS", "Extrinsic_ICMS_Apurado", "EXTENDEDPRICE", "Extrinsic_Aliquota_IPI"];

          const data = rows.map(r => {
            const out = { ...r };
            NUMERIC.forEach(k => { if (k in out) out[k] = toNum(out[k]); });
            return out;
          });

          const columns = isResult ? [
            { label: "Fornecedor", property: "supplierName", type: EdmType.String, width: 30 },
            { label: "Item", property: "materialCode", type: EdmType.String, width: 16 },
            { label: "Preço", property: "price", type: EdmType.Number, width: 12, scale: 2 },
            // ... adicione o resto das colunas de resultado
          ] : [
            { label: "Doc ID", property: "docId", type: EdmType.String, width: 12 },
            { label: "Fornecedor", property: "supplierName", type: EdmType.String, width: 30 },
            { label: "Item", property: "itemDescription", type: EdmType.String, width: 40 },
            { label: "Qtd", property: "quantity", type: EdmType.Number, width: 12, scale: 0 },
            { label: "Preço", property: "price", type: EdmType.Number, width: 12, scale: 2 },
            // ... adicione o resto das colunas principais
          ];

          const fileName = `${isResult ? "Resultado" : "Comparativo"}_${docId}.xlsx`;
          const sheet = new Spreadsheet({ workbook: { columns }, dataSource: data, fileName, worker: true });
          sheet.build()
            .then(() => sap.m.MessageToast.show(`Exportado: ${data.length} linha(s)`))
            .finally(() => sheet.destroy());
        }
      }
    );
  }
);